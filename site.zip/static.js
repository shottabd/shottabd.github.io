/* Shotta preview site (GitHub Pages).
   Forms cannot reach a server here, so each form offers to send the same
   details on WhatsApp or by phone instead. Search runs in the browser. */
(function () {
  var S = window.SHOTTA || {};
  var EN = (document.documentElement.lang || "").indexOf("en") === 0;
  var L = function (b, e) { return EN ? e : b; };
  var ROOT = (document.querySelector('meta[name="shotta-root"]') || {}).content || "/";
  var WA_NUM = ((S.wa || "").match(/wa\.me\/(\d+)/) || [])[1] || "8801788116045";
  var TEL = S.tel || "tel:+8801788116045";
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };
  var bnNum = function (n) { return EN ? String(n) : String(n).replace(/\d/g, function (d) { return "০১২৩৪৫৬৭৮৯"[d]; }); };

  /* ---------- dialog ---------- */
  function dialog(title, body, msg) {
    var d = document.getElementById("sdlg");
    if (!d) {
      d = document.createElement("dialog");
      d.id = "sdlg";
      d.className = "sdlg";
      document.body.appendChild(d);
      d.addEventListener("click", function (e) { if (e.target === d) d.close(); });
    }
    var wa = "https://wa.me/" + WA_NUM + (msg ? "?text=" + encodeURIComponent(msg) : "");
    d.innerHTML =
      '<form method="dialog"><button class="sdlg-x" aria-label="' + L("বন্ধ করুন", "Close") + '">&times;</button></form>' +
      "<h2>" + esc(title) + "</h2><p>" + body + "</p>" +
      '<div class="cta-row"><a class="btn primary" href="' + esc(wa) + '" target="_blank" rel="noopener">' + L("WhatsApp-এ পাঠান", "Send on WhatsApp") + "</a>" +
      '<a class="btn ghost" href="' + esc(TEL) + '">' + L("ফোন করুন", "Call us") + "</a></div>" +
      '<p class="hint">' + L("এটি সত্তার দেখানোর সংস্করণ। আসল সাইটে এই ফর্ম সরাসরি সত্তার কাছে জমা হবে।", "This is Shotta's preview site. On the live site this form goes straight to Shotta.") + "</p>";
    if (typeof d.showModal === "function") d.showModal(); else d.setAttribute("open", "");
  }

  /* ---------- forms ---------- */
  function val(f, n) { var el = f.elements[n]; if (!el) return ""; if (el.length && !el.tagName) { for (var i = 0; i < el.length; i++) if (el[i].checked) return el[i].value; return ""; } return (el.value || "").trim(); }
  function lines(f, pairs) {
    return pairs.map(function (p) { var v = val(f, p[0]); return v ? p[1] + ": " + v : ""; }).filter(Boolean).join("\n");
  }
  var MSG = {
    seba: function (f) {
      return L("আসসালামু আলাইকুম। সত্তার মাধ্যমে একজন বিশেষজ্ঞের সাথে কথা বলতে চাই।\n", "Hello, I would like to talk to a professional through Shotta.\n") +
        lines(f, [["name", L("নাম", "Name")], ["phone", L("মোবাইল", "Mobile")], ["district", L("জেলা", "District")], ["who", L("কার জন্য", "For")], ["topic", L("বিষয়", "Topic")], ["mode", L("মাধ্যম", "Mode")], ["gender_pref", L("পছন্দ", "Preference")], ["note", L("সংক্ষেপে", "Note")]]);
    },
    booking: function (f) {
      var who = (document.querySelector("h1") || {}).textContent || "";
      return L("আসসালামু আলাইকুম। " + who + "-এর সাথে একটি সেশন নিতে চাই।\n", "Hello, I would like a session with " + who + ".\n") +
        lines(f, [["name", L("নাম", "Name")], ["phone", L("মোবাইল", "Mobile")], ["mode", L("মাধ্যম", "Mode")], ["slot", L("সময়", "Time")], ["note", L("সংক্ষেপে", "Note")]]);
    },
    order: function (f) {
      var books = {};
      try { books = JSON.parse((document.getElementById("cart-books") || {}).textContent || "{}"); } catch (e) {}
      var items = {};
      try { items = JSON.parse(val(f, "items") || "{}"); } catch (e) {}
      var list = Object.keys(items).map(function (id) { var b = books[id] || {}; return "- " + (b.t || id) + " × " + bnNum(items[id]); }).join("\n");
      var pay = val(f, "pay") === "bkash" ? L("বিকাশ", "bKash") : L("ক্যাশ অন ডেলিভারি", "Cash on delivery");
      var total = (document.getElementById("c-total") || {}).textContent || "";
      return L("আসসালামু আলাইকুম। সত্তা শপ থেকে বই অর্ডার করতে চাই।\n", "Hello, I would like to order from Shotta Shop.\n") + list + "\n" +
        L("মোট: ", "Total: ") + total + "\n" +
        lines(f, [["name", L("নাম", "Name")], ["phone", L("মোবাইল", "Mobile")], ["district", L("এলাকা", "Area")], ["address", L("ঠিকানা", "Address")]]) + "\n" + L("পেমেন্ট: ", "Payment: ") + pay;
    },
    admission: function (f) {
      return L("আসসালামু আলাইকুম। এমএস ভর্তি প্রস্তুতির ফ্রি মডেল টেস্টের খবর পেতে চাই।\n", "Hello, please keep me posted about the free MS admission model tests.\n") +
        lines(f, [["name", L("নাম", "Name")], ["phone", L("মোবাইল", "Mobile")], ["dept", L("বিভাগ", "Department")], ["uni", L("বিশ্ববিদ্যালয়", "University")]]);
    },
    mock: function (f) {
      return L("আসসালামু আলাইকুম। নমুনা মডেল টেস্টের ফলাফল মেধাতালিকায় দিতে চাই।\n", "Hello, I would like to submit my model test result.\n") +
        lines(f, [["name", L("নাম", "Name")], ["phone", L("মোবাইল", "Mobile")], ["score", L("নম্বর", "Score")], ["total", L("মোট", "Out of")]]);
    },
    join: function () { return L("আসসালামু আলাইকুম। সত্তায় প্রফেশনাল হিসেবে যুক্ত হতে চাই।", "Hello, I would like to join Shotta as a professional."); },
    newsletter: function (f) { return L("আসসালামু আলাইকুম। সত্তার মাসিক চিঠি পেতে চাই: ", "Hello, please add me to the Shotta letter: ") + val(f, "email"); },
    review: function (f) { return L("বইয়ের রিভিউ: ", "Book review: ") + ((document.querySelector("h1") || {}).textContent || "") + "\n" + val(f, "text"); }
  };
  document.addEventListener("submit", function (e) {
    var f = e.target;
    if (!f.hasAttribute("data-static-form")) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    var type = val(f, "lead_type");
    var make = MSG[type] || function () { return ""; };
    var titles = {
      seba: L("আপনার অনুরোধ তৈরি", "Your request is ready"),
      order: L("আপনার অর্ডার তৈরি", "Your order is ready"),
      join: L("আবেদন পাঠাতে", "To send your application")
    };
    var body = type === "join"
      ? L("প্রফেশনাল আবেদনে কাগজপত্র লাগে, তাই আসল সাইট চালু হলে সেখানে জমা দিন। এখনই কথা বলতে চাইলে WhatsApp বা ফোনে যোগাযোগ করুন।", "Professional applications need documents, so please apply on the live site. To talk now, use WhatsApp or call.")
      : L("নিচের বোতামে চাপলে আপনার দেওয়া তথ্যসহ একটি মেসেজ WhatsApp-এ তৈরি হয়ে যাবে; শুধু পাঠিয়ে দিন। চাইলে সরাসরি ফোনও করতে পারেন।", "Tap the button below and WhatsApp opens with your details already written; just press send. You can also call us directly.");
    dialog(titles[type] || L("প্রায় শেষ", "Almost done"), body, make(f));
  }, true);

  /* ---------- search ---------- */
  var box = document.getElementById("static-search");
  if (!box) return;
  var q = (new URLSearchParams(location.search).get("q") || "").trim();
  var input = document.getElementById("sq");
  if (input) input.value = q;
  if (!q) return;
  fetch(ROOT + "search-index.json").then(function (r) { return r.json(); }).then(function (idx) {
    var items = idx[EN ? "en" : "bn"] || [];
    var words = q.toLowerCase().split(/\s+/).filter(Boolean);
    var groups = words.map(function (w) {
      var g = [w];
      (idx.syn || []).forEach(function (s) { if (s.some(function (x) { return x.toLowerCase().indexOf(w) === 0 || w.indexOf(x.toLowerCase()) === 0; })) g = g.concat(s.map(function (x) { return x.toLowerCase(); })); });
      return g;
    });
    var order = { post: 0, shotta_pro: 1, shotta_book: 2, shotta_term: 3, page: 4 };
    var hits = items.filter(function (it) {
      return groups.every(function (g) { return g.some(function (w) { return it.s.indexOf(w) > -1; }); });
    }).map(function (it) {
      var tl = it.t.toLowerCase();
      var inTitle = groups.every(function (g) { return g.some(function (w) { return tl.indexOf(w) > -1; }); });
      return { it: it, r: (inTitle ? 0 : 10) + (order[it.y] || 0) };
    }).sort(function (a, b) { return a.r - b.r; });
    var html = '<p class="muted" style="margin-top:18px;font-size:15px">' +
      (hits.length ? L(bnNum(hits.length) + "টি ফলাফল", hits.length + " results") : L("কিছু পাওয়া যায়নি। অন্য শব্দে খুঁজে দেখুন, বাংলা বা ইংরেজিতে।", "No results. Try another word, in Bangla or English.")) + "</p>";
    if (hits.length) {
      html += '<div class="sresults">' + hits.map(function (h) {
        var href = /^(https?:)?\//.test(h.it.u) ? h.it.u : ROOT + h.it.u;
        return '<a class="sres" href="' + esc(href) + '"><span class="kind">' + esc(h.it.k) + "</span><b>" + esc(h.it.t) + '</b><span class="d">' + esc(h.it.d) + "</span></a>";
      }).join("") + "</div>";
    }
    box.innerHTML = html;
    document.title = L("খুঁজুন: ", "Search: ") + q + (EN ? " · Shotta" : " · সত্তা");
  });
})();
